import { useRef, useMemo } from 'react';
import { Canvas, useFrame } from '@react-three/fiber';
import * as THREE from 'three';

interface ParticleFieldProps {
  count?: number;
  color?: string;
}

function Particles({ count = 1000, color = '#00d4ff' }: ParticleFieldProps) {
  const mesh = useRef<THREE.Points>(null);

  const [positions, velocities] = useMemo(() => {
    const positions = new Float32Array(count * 3);
    const velocities = new Float32Array(count * 3);

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;
      positions[i3] = (Math.random() - 0.5) * 10;
      positions[i3 + 1] = (Math.random() - 0.5) * 10;
      positions[i3 + 2] = (Math.random() - 0.5) * 10;

      velocities[i3] = (Math.random() - 0.5) * 0.01;
      velocities[i3 + 1] = (Math.random() - 0.5) * 0.01;
      velocities[i3 + 2] = (Math.random() - 0.5) * 0.01;
    }

    return [positions, velocities];
  }, [count]);

  useFrame((state) => {
    if (!mesh.current) return;

    const positionAttribute = mesh.current.geometry.attributes.position;
    const posArray = positionAttribute.array as Float32Array;

    for (let i = 0; i < count; i++) {
      const i3 = i * 3;

      // Update positions with velocity
      posArray[i3] += velocities[i3];
      posArray[i3 + 1] += velocities[i3 + 1];
      posArray[i3 + 2] += velocities[i3 + 2];

      // Boundary wrapping
      if (posArray[i3] > 5) posArray[i3] = -5;
      if (posArray[i3] < -5) posArray[i3] = 5;
      if (posArray[i3 + 1] > 5) posArray[i3 + 1] = -5;
      if (posArray[i3 + 1] < -5) posArray[i3 + 1] = 5;
      if (posArray[i3 + 2] > 5) posArray[i3 + 2] = -5;
      if (posArray[i3 + 2] < -5) posArray[i3 + 2] = 5;
    }

    positionAttribute.needsUpdate = true;
    mesh.current.rotation.y = state.clock.elapsedTime * 0.02;
  });

  return (
    <points ref={mesh}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <pointsMaterial
        size={0.03}
        color={color}
        transparent
        opacity={0.8}
        sizeAttenuation
        blending={THREE.AdditiveBlending}
      />
    </points>
  );
}

function ConnectionLines({ count = 100, color = '#00d4ff' }: ParticleFieldProps) {
  const linesRef = useRef<THREE.LineSegments>(null);

  const positions = useMemo(() => {
    const positions = new Float32Array(count * 6);
    for (let i = 0; i < count; i++) {
      const i6 = i * 6;
      positions[i6] = (Math.random() - 0.5) * 8;
      positions[i6 + 1] = (Math.random() - 0.5) * 8;
      positions[i6 + 2] = (Math.random() - 0.5) * 8;
      positions[i6 + 3] = (Math.random() - 0.5) * 8;
      positions[i6 + 4] = (Math.random() - 0.5) * 8;
      positions[i6 + 5] = (Math.random() - 0.5) * 8;
    }
    return positions;
  }, [count]);

  useFrame((state) => {
    if (!linesRef.current) return;
    
    linesRef.current.rotation.y = state.clock.elapsedTime * 0.01;
    linesRef.current.rotation.x = Math.sin(state.clock.elapsedTime * 0.1) * 0.1;
  });

  return (
    <lineSegments ref={linesRef}>
      <bufferGeometry>
        <bufferAttribute
          attach="attributes-position"
          args={[positions, 3]}
        />
      </bufferGeometry>
      <lineBasicMaterial color={color} transparent opacity={0.15} blending={THREE.AdditiveBlending} />
    </lineSegments>
  );
}

function FloatingShapes({ color = '#00d4ff' }: { color?: string }) {
  const groupRef = useRef<THREE.Group>(null);

  useFrame((state) => {
    if (!groupRef.current) return;
    groupRef.current.rotation.y = state.clock.elapsedTime * 0.05;
    groupRef.current.position.y = Math.sin(state.clock.elapsedTime * 0.5) * 0.2;
  });

  return (
    <group ref={groupRef}>
      {/* Floating ring */}
      <mesh position={[2, 1, -2]}>
        <torusGeometry args={[0.5, 0.02, 16, 100]} />
        <meshBasicMaterial color={color} transparent opacity={0.3} />
      </mesh>
      
      {/* Floating cube */}
      <mesh position={[-2, -1, 1]} rotation={[0.5, 0.5, 0]}>
        <boxGeometry args={[0.3, 0.3, 0.3]} />
        <meshBasicMaterial color={color} transparent opacity={0.2} wireframe />
      </mesh>
      
      {/* Floating sphere */}
      <mesh position={[1, -2, 2]}>
        <sphereGeometry args={[0.2, 16, 16]} />
        <meshBasicMaterial color={color} transparent opacity={0.15} />
      </mesh>
    </group>
  );
}

export default function ParticleField({ count = 1000, color = '#00d4ff' }: { count?: number; color?: string }) {
  return (
    <div className="absolute inset-0 -z-10">
      <Canvas
        camera={{ position: [0, 0, 5], fov: 75 }}
        dpr={[1, 2]}
        gl={{ antialias: true, alpha: true }}
      >
        <ambientLight intensity={0.5} />
        <Particles count={count} color={color} />
        <ConnectionLines count={50} color={color} />
        <FloatingShapes color={color} />
      </Canvas>
    </div>
  );
}
