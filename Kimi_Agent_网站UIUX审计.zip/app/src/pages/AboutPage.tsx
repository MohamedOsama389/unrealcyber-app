import { useEffect, useRef } from 'react';
import { 
  Shield, 
  Target, 
  Users, 
  Award, 
  Zap, 
  Globe,
  CheckCircle,
  ArrowRight
} from 'lucide-react';
import { Link } from 'react-router-dom';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const stats = [
  { value: '10,000+', label: 'Students', icon: Users },
  { value: '500+', label: 'Video Lessons', icon: Globe },
  { value: '95%', label: 'Success Rate', icon: Target },
  { value: '50+', label: 'Expert Instructors', icon: Award },
];

const features = [
  {
    icon: Zap,
    title: 'Hands-On Learning',
    description: 'Practice in real-world scenarios with isolated lab environments.',
  },
  {
    icon: Target,
    title: 'Structured Curriculum',
    description: 'Progressive learning path from fundamentals to advanced topics.',
  },
  {
    icon: Award,
    title: 'Industry Recognition',
    description: 'Earn certificates that employers value and recognize.',
  },
  {
    icon: Users,
    title: 'Community Support',
    description: 'Learn alongside peers and get help from expert mentors.',
  },
];

const team = [
  {
    name: 'Alex Chen',
    role: 'Founder & Lead Instructor',
    bio: 'Former NSA security analyst with 15+ years in cybersecurity.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=alex',
  },
  {
    name: 'Sarah Martinez',
    role: 'Head of Curriculum',
    bio: 'CISSP certified with experience at Fortune 500 companies.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=sarah',
  },
  {
    name: 'James Wilson',
    role: 'Lead Ethical Hacking Instructor',
    bio: 'Bug bounty hunter with $500K+ in disclosed vulnerabilities.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=james',
  },
  {
    name: 'Emily Zhang',
    role: 'Networking Expert',
    bio: 'CCIE certified with 10+ years in network engineering.',
    avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=emily',
  },
];

export default function AboutPage() {
  const pageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.about-hero', {
        y: 40,
        opacity: 0,
        duration: 0.8,
      });

      gsap.from('.stat-card', {
        y: 50,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: '.stats-section',
          start: 'top 80%',
        },
      });

      gsap.from('.feature-card', {
        y: 40,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: '.features-section',
          start: 'top 80%',
        },
      });

      gsap.from('.team-card', {
        y: 40,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: '.team-section',
          start: 'top 80%',
        },
      });
    }, pageRef);

    return () => ctx.revert();
  }, []);

  return (
    <div ref={pageRef} className="min-h-screen bg-slate-950">
      <Navigation />
      
      <main className="pt-24 lg:pt-32 pb-16">
        {/* Hero Section */}
        <section className="section-padding mb-24">
          <div className="about-hero max-w-4xl mx-auto text-center">
            <div className="inline-flex items-center gap-2 px-4 py-2 rounded-full bg-cyan-500/10 border border-cyan-500/20 mb-8">
              <Shield className="w-4 h-4 text-cyan-400" />
              <span className="text-cyan-400 text-sm font-medium">About Us</span>
            </div>
            
            <h1 className="text-4xl sm:text-5xl lg:text-6xl font-bold text-white mb-6">
              Building the Next Generation of{' '}
              <span className="cyber-text-gradient">Cybersecurity Experts</span>
            </h1>
            
            <p className="text-lg text-slate-400 max-w-2xl mx-auto mb-10">
              Unreal Cyber Academy is on a mission to democratize cybersecurity education. 
              We believe everyone should have access to world-class security training.
            </p>

            <div className="flex flex-col sm:flex-row items-center justify-center gap-4">
              <Link to="/tracking">
                <Button size="lg" className="btn-primary group">
                  Start Learning
                  <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                </Button>
              </Link>
              <a href="#team">
                <Button size="lg" variant="outline" className="btn-secondary">
                  Meet the Team
                </Button>
              </a>
            </div>
          </div>
        </section>

        {/* Stats Section */}
        <section className="stats-section section-padding mb-24">
          <div className="max-w-6xl mx-auto">
            <div className="grid grid-cols-2 lg:grid-cols-4 gap-4 lg:gap-6">
              {stats.map((stat, index) => {
                const Icon = stat.icon;
                return (
                  <div key={index} className="stat-card glass-card p-6 text-center">
                    <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mx-auto mb-4">
                      <Icon className="w-6 h-6 text-cyan-400" />
                    </div>
                    <p className="text-3xl lg:text-4xl font-bold text-white mb-1">{stat.value}</p>
                    <p className="text-slate-400">{stat.label}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Mission Section */}
        <section className="section-padding mb-24">
          <div className="max-w-6xl mx-auto">
            <div className="grid lg:grid-cols-2 gap-12 items-center">
              <div>
                <span className="text-cyan-400 text-sm font-semibold uppercase tracking-widest mb-4 block">
                  Our Mission
                </span>
                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-6">
                  Why We Built Unreal Cyber Academy
                </h2>
                <div className="space-y-4 text-slate-400">
                  <p>
                    The cybersecurity skills gap is growing. By 2025, there will be 3.5 million 
                    unfilled cybersecurity jobs worldwide. We created Unreal Cyber Academy to 
                    help bridge this gap.
                  </p>
                  <p>
                    Our platform combines expert-led instruction with hands-on labs, giving 
                    students the practical skills they need to succeed in the real world.
                  </p>
                  <p>
                    Whether you are looking to start a career in cybersecurity, advance your 
                    existing skills, or prepare for industry certifications, we have got you covered.
                  </p>
                </div>

                <div className="mt-8 space-y-3">
                  {[
                    'Industry-relevant curriculum',
                    'Hands-on lab environments',
                    'Expert mentorship',
                    'Community-driven learning',
                  ].map((item, index) => (
                    <div key={index} className="flex items-center gap-3">
                      <CheckCircle className="w-5 h-5 text-green-400 flex-shrink-0" />
                      <span className="text-slate-300">{item}</span>
                    </div>
                  ))}
                </div>
              </div>

              <div className="relative">
                <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/20 to-purple-500/20 rounded-3xl blur-3xl" />
                <div className="relative glass-card p-8">
                  <div className="grid grid-cols-2 gap-4">
                    <div className="p-4 rounded-xl bg-slate-900/50 text-center">
                      <p className="text-3xl font-bold text-cyan-400 mb-1">3</p>
                      <p className="text-slate-400 text-sm">Learning Tracks</p>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900/50 text-center">
                      <p className="text-3xl font-bold text-purple-400 mb-1">74</p>
                      <p className="text-slate-400 text-sm">Total Modules</p>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900/50 text-center">
                      <p className="text-3xl font-bold text-blue-400 mb-1">200+</p>
                      <p className="text-slate-400 text-sm">Lab Exercises</p>
                    </div>
                    <div className="p-4 rounded-xl bg-slate-900/50 text-center">
                      <p className="text-3xl font-bold text-green-400 mb-1">24/7</p>
                      <p className="text-slate-400 text-sm">Lab Access</p>
                    </div>
                  </div>
                </div>
              </div>
            </div>
          </div>
        </section>

        {/* Features Section */}
        <section className="features-section section-padding mb-24">
          <div className="max-w-6xl mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-cyan-400 text-sm font-semibold uppercase tracking-widest mb-4 block">
                What Makes Us Different
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">
                Built for <span className="cyber-text-gradient">Serious Learners</span>
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 gap-6">
              {features.map((feature, index) => {
                const Icon = feature.icon;
                return (
                  <div key={index} className="feature-card glass-card-hover p-6">
                    <div className="w-12 h-12 rounded-xl bg-cyan-500/10 flex items-center justify-center mb-4">
                      <Icon className="w-6 h-6 text-cyan-400" />
                    </div>
                    <h3 className="text-xl font-bold text-white mb-2">{feature.title}</h3>
                    <p className="text-slate-400">{feature.description}</p>
                  </div>
                );
              })}
            </div>
          </div>
        </section>

        {/* Team Section */}
        <section id="team" className="team-section section-padding mb-24">
          <div className="max-w-6xl mx-auto">
            <div className="text-center max-w-2xl mx-auto mb-12">
              <span className="text-cyan-400 text-sm font-semibold uppercase tracking-widest mb-4 block">
                Our Team
              </span>
              <h2 className="text-3xl sm:text-4xl font-bold text-white">
                Meet the <span className="cyber-text-gradient">Experts</span>
              </h2>
            </div>

            <div className="grid sm:grid-cols-2 lg:grid-cols-4 gap-6">
              {team.map((member, index) => (
                <div key={index} className="team-card glass-card p-6 text-center">
                  <div className="w-24 h-24 rounded-full bg-slate-800 mx-auto mb-4 overflow-hidden">
                    <img 
                      src={member.avatar} 
                      alt={member.name}
                      className="w-full h-full object-cover"
                    />
                  </div>
                  <h3 className="text-white font-bold mb-1">{member.name}</h3>
                  <p className="text-cyan-400 text-sm mb-3">{member.role}</p>
                  <p className="text-slate-400 text-sm">{member.bio}</p>
                </div>
              ))}
            </div>
          </div>
        </section>

        {/* CTA Section */}
        <section className="section-padding">
          <div className="max-w-4xl mx-auto">
            <div className="glass-card p-8 lg:p-12 text-center relative overflow-hidden">
              <div className="absolute inset-0 bg-gradient-to-r from-cyan-500/10 via-purple-500/10 to-blue-500/10" />
              
              <div className="relative z-10">
                <h2 className="text-3xl sm:text-4xl font-bold text-white mb-4">
                  Ready to Start Your Journey?
                </h2>
                <p className="text-slate-400 max-w-xl mx-auto mb-8">
                  Join thousands of students who are already learning with Unreal Cyber Academy. 
                  Your cybersecurity career starts here.
                </p>
                <Link to="/tracking">
                  <Button size="lg" className="btn-primary group">
                    Get Started Free
                    <ArrowRight className="w-5 h-5 ml-2 group-hover:translate-x-1 transition-transform" />
                  </Button>
                </Link>
              </div>
            </div>
          </div>
        </section>
      </main>

      <Footer />
    </div>
  );
}
