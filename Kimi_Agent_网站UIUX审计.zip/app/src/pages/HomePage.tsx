import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import HeroSection from '@/sections/HeroSection';
import TracksPreview from '@/sections/TracksPreview';
import FeaturesSection from '@/sections/FeaturesSection';
import CTASection from '@/sections/CTASection';

export default function HomePage() {
  return (
    <div className="min-h-screen bg-slate-950">
      <Navigation />
      <main>
        <HeroSection />
        <TracksPreview />
        <FeaturesSection />
        <CTASection />
      </main>
      <Footer />
    </div>
  );
}
