import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  User, 
  Edit2, 
  Settings, 
  LogOut,
  Shield,
  Award,
  BookOpen,
  Clock,
  CheckCircle,
  TrendingUp,
  Flame,
  Star,
  Zap,
  Globe,
  Code,
  Lock,
  Target,
  Trophy
} from 'lucide-react';
import { useAuthStore } from '@/store/authStore';
import { useProgressStore } from '@/store/progressStore';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const trackIcons: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  networking: Globe,
  'ethical-hacking': Shield,
  programming: Code,
};

const activityIcons: Record<string, React.ComponentType<{ className?: string; style?: React.CSSProperties }>> = {
  video_completed: CheckCircle,
  module_completed: BookOpen,
  exam_passed: Award,
  badge_earned: Star,
};

const activityColors: Record<string, string> = {
  video_completed: 'text-cyan-400 bg-cyan-500/10',
  module_completed: 'text-green-400 bg-green-500/10',
  exam_passed: 'text-purple-400 bg-purple-500/10',
  badge_earned: 'text-amber-400 bg-amber-500/10',
};

export default function ProfilePage() {
  const { user, isAuthenticated, logout } = useAuthStore();
  const { tracks, achievements, activities, totalXp } = useProgressStore();
  const pageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.profile-header', {
        y: 30,
        opacity: 0,
        duration: 0.6,
      });

      gsap.from('.profile-card', {
        y: 40,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        scrollTrigger: {
          trigger: '.profile-content',
          start: 'top 80%',
        },
      });
    }, pageRef);

    return () => ctx.revert();
  }, []);

  const completedModules = tracks.reduce(
    (acc, track) => acc + track.modules.filter(m => m.status === 'completed').length,
    0
  );

  const unlockedAchievements = achievements.filter(a => a.unlockedAt);

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));

    if (days > 0) return `${days}d ago`;
    if (hours > 0) return `${hours}h ago`;
    return `${minutes}m ago`;
  };

  const getRankFrame = (level: number) => {
    if (level >= 50) return 'legendary';
    if (level >= 25) return 'gold';
    if (level >= 10) return 'silver';
    return 'bronze';
  };

  const frameStyles: Record<string, string> = {
    bronze: 'from-amber-600 to-amber-800',
    silver: 'from-slate-300 to-slate-500',
    gold: 'from-yellow-400 to-yellow-600',
    legendary: 'from-cyan-400 via-purple-500 to-pink-500',
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Navigation />
        <main className="pt-24 lg:pt-32 pb-16 flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-20 h-20 rounded-full bg-slate-900 flex items-center justify-center mx-auto mb-6">
              <User className="w-10 h-10 text-slate-500" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Sign In Required</h1>
            <p className="text-slate-400 mb-6">Please sign in to view your profile.</p>
            <Link to="/login">
              <button className="btn-primary">Sign In</button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div ref={pageRef} className="min-h-screen bg-slate-950">
      <Navigation />
      
      <main className="pt-24 lg:pt-32 pb-16">
        <div className="section-padding">
          <div className="profile-content max-w-6xl mx-auto">
            {/* Profile Header */}
            <div className="profile-header glass-card p-8 mb-8">
              <div className="flex flex-col lg:flex-row items-center gap-8">
                {/* Avatar */}
                <div className="relative">
                  <div className={`w-32 h-32 rounded-full p-1 bg-gradient-to-br ${frameStyles[getRankFrame(user?.level || 0)]}`}>
                    <div className="w-full h-full rounded-full bg-slate-900 flex items-center justify-center overflow-hidden">
                      {user?.avatar ? (
                        <img 
                          src={user.avatar} 
                          alt={user.username}
                          className="w-full h-full object-cover"
                        />
                      ) : (
                        <User className="w-16 h-16 text-slate-500" />
                      )}
                    </div>
                  </div>
                  <button 
                    className="absolute bottom-0 right-0 w-8 h-8 rounded-full bg-slate-800 border border-white/10 flex items-center justify-center hover:bg-slate-700 transition-colors"
                  >
                    <Edit2 className="w-4 h-4 text-slate-400" />
                  </button>
                </div>

                {/* User Info */}
                <div className="text-center lg:text-left flex-1">
                  <div className="flex flex-col lg:flex-row lg:items-center gap-2 mb-2">
                    <h1 className="text-3xl font-bold text-white">@{user?.username}</h1>
                    <span className="px-3 py-1 rounded-full bg-cyan-500/10 text-cyan-400 text-sm font-medium">
                      {user?.rank}
                    </span>
                  </div>
                  <p className="text-slate-400 mb-4">{user?.email}</p>
                  
                  <div className="flex flex-wrap items-center justify-center lg:justify-start gap-4 text-sm">
                    <div className="flex items-center gap-2">
                      <Zap className="w-4 h-4 text-amber-400" />
                      <span className="text-slate-300">{totalXp.toLocaleString()} XP</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <TrendingUp className="w-4 h-4 text-green-400" />
                      <span className="text-slate-300">Level {user?.level}</span>
                    </div>
                    <div className="flex items-center gap-2">
                      <Clock className="w-4 h-4 text-blue-400" />
                      <span className="text-slate-300">Joined {new Date(user?.joinedAt || '').toLocaleDateString()}</span>
                    </div>
                  </div>
                </div>

                {/* Actions */}
                <div className="flex flex-col gap-3">
                  <Button 
                    variant="outline" 
                    className="border-white/10 text-slate-300 hover:bg-white/5"
                  >
                    <Edit2 className="w-4 h-4 mr-2" />
                    Edit Profile
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-white/10 text-slate-300 hover:bg-white/5"
                  >
                    <Settings className="w-4 h-4 mr-2" />
                    Settings
                  </Button>
                  <Button 
                    variant="outline" 
                    className="border-red-500/20 text-red-400 hover:bg-red-500/10"
                    onClick={logout}
                  >
                    <LogOut className="w-4 h-4 mr-2" />
                    Logout
                  </Button>
                </div>
              </div>
            </div>

            <div className="grid lg:grid-cols-3 gap-8">
              {/* Left Column */}
              <div className="lg:col-span-2 space-y-8">
                {/* Enrolled Tracks */}
                <div className="profile-card">
                  <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                    <BookOpen className="w-5 h-5 text-cyan-400" />
                    Enrolled Tracks
                  </h3>
                  <div className="space-y-4">
                    {tracks.map((track) => {
                      const Icon = trackIcons[track.id] || Globe;
                      const progress = track.totalModules > 0 
                        ? (track.modulesCompleted / track.totalModules) * 100 
                        : 0;

                      return (
                        <div key={track.id} className="glass-card p-4">
                          <div className="flex items-center gap-4 mb-3">
                            <div 
                              className="w-12 h-12 rounded-xl flex items-center justify-center"
                              style={{ backgroundColor: `${track.color}20` }}
                            >
                              <Icon className="w-6 h-6" style={{ color: track.color } as React.CSSProperties} />
                            </div>
                            <div className="flex-1">
                              <h4 className="text-white font-medium">{track.name}</h4>
                              <p className="text-slate-500 text-sm">
                                {track.modulesCompleted}/{track.totalModules} modules
                              </p>
                            </div>
                            {!track.unlocked && (
                              <div className="flex items-center gap-1 text-slate-500 text-sm">
                                <Lock className="w-4 h-4" />
                                Locked
                              </div>
                            )}
                          </div>
                          {track.unlocked && (
                            <div>
                              <div className="flex justify-between text-sm mb-1">
                                <span className="text-slate-400">Progress</span>
                                <span className="text-white">{Math.round(progress)}%</span>
                              </div>
                              <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                                <div 
                                  className="h-full rounded-full transition-all"
                                  style={{ width: `${progress}%`, backgroundColor: track.color }}
                                />
                              </div>
                            </div>
                          )}
                        </div>
                      );
                    })}
                  </div>
                </div>

                {/* Recent Activity */}
                <div className="profile-card">
                  <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                    <Clock className="w-5 h-5 text-blue-400" />
                    Recent Activity
                  </h3>
                  <div className="space-y-3">
                    {activities.slice(0, 6).map((activity) => {
                      const Icon = activityIcons[activity.type] || CheckCircle;
                      return (
                        <div 
                          key={activity.id} 
                          className="flex items-center gap-4 p-3 rounded-lg hover:bg-slate-900/50 transition-colors"
                        >
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center ${activityColors[activity.type] || 'text-slate-400 bg-slate-500/10'}`}>
                            <Icon className="w-5 h-5" />
                          </div>
                          <div className="flex-1">
                            <p className="text-white text-sm">{activity.title}</p>
                          </div>
                          <span className="text-slate-500 text-xs">{formatTimeAgo(activity.timestamp)}</span>
                        </div>
                      );
                    })}
                  </div>
                </div>
              </div>

              {/* Right Column */}
              <div className="space-y-8">
                {/* Stats */}
                <div className="profile-card glass-card p-6">
                  <h3 className="text-lg font-bold text-white mb-6">Statistics</h3>
                  <div className="space-y-4">
                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                          <CheckCircle className="w-5 h-5 text-cyan-400" />
                        </div>
                        <span className="text-slate-300">Modules</span>
                      </div>
                      <span className="text-white font-bold">{completedModules}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                          <Award className="w-5 h-5 text-amber-400" />
                        </div>
                        <span className="text-slate-300">Achievements</span>
                      </div>
                      <span className="text-white font-bold">{unlockedAchievements.length}</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                          <Flame className="w-5 h-5 text-purple-400" />
                        </div>
                        <span className="text-slate-300">Day Streak</span>
                      </div>
                      <span className="text-white font-bold">7</span>
                    </div>

                    <div className="flex items-center justify-between">
                      <div className="flex items-center gap-3">
                        <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                          <Zap className="w-5 h-5 text-green-400" />
                        </div>
                        <span className="text-slate-300">Total XP</span>
                      </div>
                      <span className="text-white font-bold">{totalXp.toLocaleString()}</span>
                    </div>
                  </div>
                </div>

                {/* Achievement Showcase */}
                <div className="profile-card">
                  <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                    <Star className="w-5 h-5 text-amber-400" />
                    Achievement Showcase
                  </h3>
                  <div className="grid grid-cols-3 gap-3">
                    {unlockedAchievements.slice(0, 6).map((achievement) => {
                      const Icon = achievement.icon === 'Footprints' ? TrendingUp :
                                  achievement.icon === 'Flame' ? Flame :
                                  achievement.icon === 'Layers' ? Target :
                                  achievement.icon === 'Network' ? Trophy :
                                  achievement.icon === 'Trophy' ? Award : Star;

                      return (
                        <div 
                          key={achievement.id}
                          className="aspect-square rounded-xl bg-slate-900/50 flex flex-col items-center justify-center p-3 hover:bg-slate-800/50 transition-colors cursor-pointer group"
                          title={achievement.title}
                        >
                          <div className={`w-10 h-10 rounded-lg flex items-center justify-center mb-2 ${
                            achievement.rarity === 'legendary' ? 'bg-amber-500/10' :
                            achievement.rarity === 'epic' ? 'bg-purple-500/10' :
                            achievement.rarity === 'rare' ? 'bg-cyan-500/10' :
                            'bg-slate-700/50'
                          }`}>
                            <Icon className={`w-5 h-5 ${
                              achievement.rarity === 'legendary' ? 'text-amber-400' :
                              achievement.rarity === 'epic' ? 'text-purple-400' :
                              achievement.rarity === 'rare' ? 'text-cyan-400' :
                              'text-slate-400'
                            }`} />
                          </div>
                          <span className="text-xs text-slate-400 text-center truncate w-full">
                            {achievement.title}
                          </span>
                        </div>
                      );
                    })}
                    {unlockedAchievements.length < 6 && (
                      <div className="aspect-square rounded-xl border-2 border-dashed border-slate-700 flex flex-col items-center justify-center p-3">
                        <div className="w-10 h-10 rounded-lg bg-slate-800 flex items-center justify-center mb-2">
                          <Lock className="w-5 h-5 text-slate-500" />
                        </div>
                        <span className="text-xs text-slate-500 text-center">Locked</span>
                      </div>
                    )}
                  </div>
                </div>

                {/* Next Level */}
                <div className="profile-card glass-card p-6">
                  <h3 className="text-lg font-bold text-white mb-4">Next Level</h3>
                  <div className="flex items-center justify-between mb-3">
                    <span className="text-slate-400">Level {user?.level}</span>
                    <span className="text-white font-medium">Level {(user?.level || 0) + 1}</span>
                  </div>
                  <div className="h-3 bg-slate-800 rounded-full overflow-hidden mb-3">
                    <div 
                      className="h-full bg-gradient-to-r from-cyan-500 to-purple-500 rounded-full"
                      style={{ width: '65%' }}
                    />
                  </div>
                  <p className="text-slate-500 text-sm text-center">
                    550 XP to next level
                  </p>
                </div>
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
