import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Trophy, 
  Target, 
  TrendingUp, 
  Award,
  Clock,
  CheckCircle,
  ArrowRight,
  Flame,
  Star,
  Zap,
  Play
} from 'lucide-react';
import { useProgressStore } from '@/store/progressStore';
import { useAuthStore } from '@/store/authStore';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const rarityColors: Record<string, string> = {
  common: 'text-slate-400 bg-slate-500/10 border-slate-500/20',
  rare: 'text-cyan-400 bg-cyan-500/10 border-cyan-500/20',
  epic: 'text-purple-400 bg-purple-500/10 border-purple-500/20',
  legendary: 'text-amber-400 bg-amber-500/10 border-amber-500/20',
};

const rarityLabels: Record<string, string> = {
  common: 'Common',
  rare: 'Rare',
  epic: 'Epic',
  legendary: 'Legendary',
};

function SkillRadar({ tracks }: { tracks: { name: string; progress: number; color: string }[] }) {
  const size = 200;
  const center = size / 2;
  const radius = 70;
  const angleStep = (2 * Math.PI) / tracks.length;

  const points = tracks.map((track, i) => {
    const angle = i * angleStep - Math.PI / 2;
    const r = radius * (track.progress / 100);
    return {
      x: center + r * Math.cos(angle),
      y: center + r * Math.sin(angle),
    };
  });

  const pathData = points.map((p, i) => `${i === 0 ? 'M' : 'L'} ${p.x} ${p.y}`).join(' ') + ' Z';

  return (
    <div className="relative w-full flex justify-center">
      <svg width={size} height={size} className="transform -rotate-0">
        {/* Background grid */}
        {[0.25, 0.5, 0.75, 1].map((scale) => (
          <polygon
            key={scale}
            points={tracks.map((_, i) => {
              const angle = i * angleStep - Math.PI / 2;
              const r = radius * scale;
              return `${center + r * Math.cos(angle)},${center + r * Math.sin(angle)}`;
            }).join(' ')}
            fill="none"
            stroke="rgba(255,255,255,0.05)"
            strokeWidth="1"
          />
        ))}

        {/* Axis lines */}
        {tracks.map((_, i) => {
          const angle = i * angleStep - Math.PI / 2;
          return (
            <line
              key={i}
              x1={center}
              y1={center}
              x2={center + radius * Math.cos(angle)}
              y2={center + radius * Math.sin(angle)}
              stroke="rgba(255,255,255,0.05)"
              strokeWidth="1"
            />
          );
        })}

        {/* Data area */}
        <path
          d={pathData}
          fill="url(#gradient)"
          stroke="rgba(0,212,255,0.5)"
          strokeWidth="2"
          opacity="0.8"
        />

        {/* Gradient definition */}
        <defs>
          <linearGradient id="gradient" x1="0%" y1="0%" x2="100%" y2="100%">
            <stop offset="0%" stopColor="rgba(0,212,255,0.3)" />
            <stop offset="100%" stopColor="rgba(168,85,247,0.3)" />
          </linearGradient>
        </defs>
      </svg>

      {/* Labels */}
      <div className="absolute inset-0">
        {tracks.map((track, i) => {
          const angle = i * angleStep - Math.PI / 2;
          const labelRadius = radius + 25;
          const x = center + labelRadius * Math.cos(angle);
          const y = center + labelRadius * Math.sin(angle);

          return (
            <div
              key={track.name}
              className="absolute text-xs text-slate-400 whitespace-nowrap"
              style={{
                left: `${(x / size) * 100}%`,
                top: `${(y / size) * 100}%`,
                transform: 'translate(-50%, -50%)',
              }}
            >
              {track.name}
            </div>
          );
        })}
      </div>
    </div>
  );
}

export default function ProgressPage() {
  const { tracks, achievements, activities, overallProgress, totalXp } = useProgressStore();
  const { user, isAuthenticated } = useAuthStore();
  const pageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.progress-header', {
        y: 30,
        opacity: 0,
        duration: 0.6,
      });

      gsap.from('.stats-card', {
        y: 40,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: '.stats-grid',
          start: 'top 80%',
        },
      });

      gsap.from('.achievements-grid', {
        y: 40,
        opacity: 0,
        duration: 0.6,
        scrollTrigger: {
          trigger: '.achievements-section',
          start: 'top 80%',
        },
      });
    }, pageRef);

    return () => ctx.revert();
  }, []);

  const completedModules = tracks.reduce(
    (acc, track) => acc + track.modules.filter(m => m.status === 'completed').length,
    0
  );
  const totalModules = tracks.reduce((acc, track) => acc + track.modules.length, 0);

  const completedExams = tracks.reduce(
    (acc, track) => acc + track.modules.filter(m => m.exam.status === 'completed').length,
    0
  );

  const examScores = tracks.flatMap(track =>
    track.modules
      .filter(m => m.exam.status === 'completed' && m.exam.score !== null)
      .map(m => ({ title: m.exam.title, score: m.exam.score! }))
  );

  const skillData = tracks.map(track => ({
    name: track.name.split(' ')[0],
    progress: track.totalModules > 0 ? (track.modulesCompleted / track.totalModules) * 100 : 0,
    color: track.color,
  }));

  const unlockedAchievements = achievements.filter(a => a.unlockedAt);

  const formatTimeAgo = (timestamp: string) => {
    const date = new Date(timestamp);
    const now = new Date();
    const diff = now.getTime() - date.getTime();
    const days = Math.floor(diff / (1000 * 60 * 60 * 24));
    const hours = Math.floor(diff / (1000 * 60 * 60));
    const minutes = Math.floor(diff / (1000 * 60));

    if (days > 0) return `${days} day${days > 1 ? 's' : ''} ago`;
    if (hours > 0) return `${hours} hour${hours > 1 ? 's' : ''} ago`;
    return `${minutes} minute${minutes > 1 ? 's' : ''} ago`;
  };

  if (!isAuthenticated) {
    return (
      <div className="min-h-screen bg-slate-950">
        <Navigation />
        <main className="pt-24 lg:pt-32 pb-16 flex items-center justify-center min-h-[60vh]">
          <div className="text-center">
            <div className="w-20 h-20 rounded-full bg-slate-900 flex items-center justify-center mx-auto mb-6">
              <Trophy className="w-10 h-10 text-slate-500" />
            </div>
            <h1 className="text-2xl font-bold text-white mb-2">Sign In Required</h1>
            <p className="text-slate-400 mb-6">Please sign in to view your progress.</p>
            <Link to="/login">
              <button className="btn-primary">Sign In</button>
            </Link>
          </div>
        </main>
        <Footer />
      </div>
    );
  }

  return (
    <div ref={pageRef} className="min-h-screen bg-slate-950">
      <Navigation />
      
      <main className="pt-24 lg:pt-32 pb-16">
        <div className="section-padding">
          {/* Header */}
          <div className="progress-header max-w-5xl mx-auto text-center mb-12">
            <div className="flex flex-col lg:flex-row lg:items-center gap-6 mb-8">
              <div className="flex items-center gap-4">
                <div className="w-20 h-20 rounded-2xl bg-gradient-to-br from-cyan-500 to-purple-600 flex items-center justify-center">
                  <Trophy className="w-10 h-10 text-white" />
                </div>
                <div>
                  <span className="text-cyan-400 text-sm font-medium">{user?.rank}</span>
                  <h1 className="text-3xl sm:text-4xl font-bold text-white">Your Progress</h1>
                  <p className="text-slate-400">Level {user?.level} • {totalXp.toLocaleString()} XP</p>
                </div>
              </div>

              <div className="lg:ml-auto">
                <Link to="/tracking">
                  <button className="btn-secondary flex items-center gap-2">
                    Continue Learning
                    <ArrowRight className="w-4 h-4" />
                  </button>
                </Link>
              </div>
            </div>

            {/* Overall Progress Bar */}
            <div className="glass-card p-6">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-400">Overall Completion</span>
                <span className="text-2xl font-bold text-white">{overallProgress}%</span>
              </div>
              <div className="h-4 bg-slate-800 rounded-full overflow-hidden">
                <div className="h-full progress-gradient rounded-full" style={{ width: `${overallProgress}%` }} />
              </div>
              <p className="text-slate-500 text-sm mt-3">
                {completedModules} of {totalModules} modules completed across all tracks
              </p>
            </div>
          </div>

          {/* Stats Grid */}
          <div className="stats-grid grid sm:grid-cols-2 lg:grid-cols-4 gap-4 max-w-6xl mx-auto mb-12">
            <div className="stats-card glass-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center">
                  <CheckCircle className="w-5 h-5 text-cyan-400" />
                </div>
                <span className="text-slate-400 text-sm">Modules</span>
              </div>
              <p className="text-3xl font-bold text-white">{completedModules}</p>
              <p className="text-slate-500 text-sm">Completed</p>
            </div>

            <div className="stats-card glass-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-purple-500/10 flex items-center justify-center">
                  <Award className="w-5 h-5 text-purple-400" />
                </div>
                <span className="text-slate-400 text-sm">Exams</span>
              </div>
              <p className="text-3xl font-bold text-white">{completedExams}</p>
              <p className="text-slate-500 text-sm">Passed</p>
            </div>

            <div className="stats-card glass-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-amber-500/10 flex items-center justify-center">
                  <Star className="w-5 h-5 text-amber-400" />
                </div>
                <span className="text-slate-400 text-sm">Achievements</span>
              </div>
              <p className="text-3xl font-bold text-white">{unlockedAchievements.length}</p>
              <p className="text-slate-500 text-sm">Unlocked</p>
            </div>

            <div className="stats-card glass-card p-6">
              <div className="flex items-center gap-3 mb-3">
                <div className="w-10 h-10 rounded-lg bg-green-500/10 flex items-center justify-center">
                  <Zap className="w-5 h-5 text-green-400" />
                </div>
                <span className="text-slate-400 text-sm">XP Earned</span>
              </div>
              <p className="text-3xl font-bold text-white">{totalXp.toLocaleString()}</p>
              <p className="text-slate-500 text-sm">Total</p>
            </div>
          </div>

          {/* Skill Distribution & Exam Scores */}
          <div className="grid lg:grid-cols-2 gap-6 max-w-6xl mx-auto mb-12">
            {/* Skill Radar */}
            <div className="glass-card p-6">
              <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                <Target className="w-5 h-5 text-cyan-400" />
                Skill Distribution
              </h3>
              <SkillRadar tracks={skillData} />
              <div className="mt-6 space-y-3">
                {skillData.map((skill) => (
                  <div key={skill.name} className="flex items-center gap-3">
                    <div 
                      className="w-3 h-3 rounded-full" 
                      style={{ backgroundColor: skill.color }}
                    />
                    <span className="text-slate-300 flex-1">{skill.name}</span>
                    <span className="text-white font-medium">{Math.round(skill.progress)}%</span>
                  </div>
                ))}
              </div>
            </div>

            {/* Exam Scores */}
            <div className="glass-card p-6">
              <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
                <TrendingUp className="w-5 h-5 text-purple-400" />
                Recent Exam Scores
              </h3>
              <div className="space-y-4">
                {examScores.length > 0 ? (
                  examScores.map((exam, idx) => (
                    <div key={idx} className="flex items-center gap-4 p-4 rounded-lg bg-slate-900/50">
                      <div className={`w-12 h-12 rounded-lg flex items-center justify-center ${
                        exam.score >= 90 ? 'bg-green-500/10' :
                        exam.score >= 80 ? 'bg-cyan-500/10' :
                        'bg-amber-500/10'
                      }`}>
                        <span className={`text-lg font-bold ${
                          exam.score >= 90 ? 'text-green-400' :
                          exam.score >= 80 ? 'text-cyan-400' :
                          'text-amber-400'
                        }`}>
                          {exam.score >= 90 ? 'A' : exam.score >= 80 ? 'B' : 'C'}
                        </span>
                      </div>
                      <div className="flex-1">
                        <p className="text-white font-medium">{exam.title}</p>
                        <p className="text-slate-500 text-sm">{exam.score}% Score</p>
                      </div>
                      <div className="text-right">
                        <span className={`px-3 py-1 rounded-full text-sm font-medium ${
                          exam.score >= 90 ? 'bg-green-500/20 text-green-400' :
                          exam.score >= 80 ? 'bg-cyan-500/20 text-cyan-400' :
                          'bg-amber-500/20 text-amber-400'
                        }`}>
                          {exam.score}%
                        </span>
                      </div>
                    </div>
                  ))
                ) : (
                  <div className="text-center py-8">
                    <p className="text-slate-500">No exams completed yet.</p>
                    <Link to="/tracking" className="text-cyan-400 hover:text-cyan-300 text-sm mt-2 inline-block">
                      Start learning →
                    </Link>
                  </div>
                )}
              </div>
            </div>
          </div>

          {/* Achievements */}
          <div className="achievements-section max-w-6xl mx-auto mb-12">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Flame className="w-5 h-5 text-amber-400" />
              Achievements
            </h3>
            <div className="achievements-grid grid sm:grid-cols-2 lg:grid-cols-4 gap-4">
              {achievements.map((achievement) => {
                const isUnlocked = !!achievement.unlockedAt;
                const Icon = achievement.icon === 'Footprints' ? TrendingUp :
                            achievement.icon === 'Flame' ? Flame :
                            achievement.icon === 'Layers' ? Target :
                            achievement.icon === 'Network' ? Trophy :
                            achievement.icon === 'Trophy' ? Award : Star;

                return (
                  <div
                    key={achievement.id}
                    className={`glass-card p-4 transition-all ${
                      isUnlocked ? '' : 'opacity-50'
                    }`}
                  >
                    <div className={`w-12 h-12 rounded-xl flex items-center justify-center mb-3 ${
                      isUnlocked ? rarityColors[achievement.rarity] : 'bg-slate-800 text-slate-500'
                    }`}>
                      <Icon className="w-6 h-6" />
                    </div>
                    <h4 className="text-white font-medium mb-1">{achievement.title}</h4>
                    <p className="text-slate-400 text-sm mb-3">{achievement.description}</p>
                    <div className="flex items-center justify-between">
                      <span className={`text-xs px-2 py-0.5 rounded-full border ${
                        rarityColors[achievement.rarity]
                      }`}>
                        {rarityLabels[achievement.rarity]}
                      </span>
                      {isUnlocked && (
                        <span className="text-green-400 text-xs flex items-center gap-1">
                          <CheckCircle className="w-3 h-3" />
                          Unlocked
                        </span>
                      )}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>

          {/* Recent Activity */}
          <div className="max-w-6xl mx-auto">
            <h3 className="text-lg font-bold text-white mb-6 flex items-center gap-2">
              <Clock className="w-5 h-5 text-blue-400" />
              Recent Activity
            </h3>
            <div className="glass-card p-6">
              <div className="space-y-4">
                {activities.slice(0, 5).map((activity) => (
                  <div key={activity.id} className="flex items-center gap-4 p-3 rounded-lg hover:bg-slate-900/50 transition-colors">
                    <div className="w-10 h-10 rounded-lg bg-cyan-500/10 flex items-center justify-center flex-shrink-0">
                      {activity.type === 'video_completed' && <Play className="w-5 h-5 text-cyan-400" />}
                      {activity.type === 'module_completed' && <CheckCircle className="w-5 h-5 text-green-400" />}
                      {activity.type === 'exam_passed' && <Award className="w-5 h-5 text-purple-400" />}
                      {activity.type === 'badge_earned' && <Star className="w-5 h-5 text-amber-400" />}
                    </div>
                    <div className="flex-1">
                      <p className="text-white">{activity.title}</p>
                    </div>
                    <span className="text-slate-500 text-sm">{formatTimeAgo(activity.timestamp)}</span>
                  </div>
                ))}
              </div>
            </div>
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
