import { useState, useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { 
  Globe, 
  Shield, 
  Code, 
  ChevronDown, 
  ChevronUp,
  Play,
  FileText,
  CheckCircle,
  Lock,
  Clock,
  Award,
  ArrowRight,
  BookOpen
} from 'lucide-react';
import { useProgressStore, type Track, type Module } from '@/store/progressStore';
import { Button } from '@/components/ui/button';
import Navigation from '@/components/Navigation';
import Footer from '@/components/Footer';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const trackIcons = {
  Globe: Globe,
  Shield: Shield,
  Code: Code,
};

function ModuleCard({ 
  module, 
  trackColor, 
  isExpanded, 
  onToggle 
}: { 
  module: Module; 
  trackColor: string;
  isExpanded: boolean;
  onToggle: () => void;
}) {
  const completedVideos = module.videos.filter(v => v.status === 'watched').length;
  const totalVideos = module.videos.length;
  const videoProgress = totalVideos > 0 ? (completedVideos / totalVideos) * 100 : 0;

  const getStatusIcon = () => {
    switch (module.status) {
      case 'completed':
        return <CheckCircle className="w-5 h-5 text-green-400" />;
      case 'in-progress':
        return <Play className="w-5 h-5 text-cyan-400" />;
      case 'locked':
        return <Lock className="w-5 h-5 text-slate-500" />;
      default:
        return <BookOpen className="w-5 h-5 text-slate-400" />;
    }
  };

  const getStatusClass = () => {
    switch (module.status) {
      case 'completed':
        return 'border-green-500/30 bg-green-500/5';
      case 'in-progress':
        return '';
      case 'locked':
        return 'border-slate-700/50 opacity-60';
      default:
        return 'border-slate-700/50';
    }
  };

  return (
    <div 
      className={`glass-card overflow-hidden transition-all duration-300 ${getStatusClass()}`}
      style={{ borderColor: module.status === 'in-progress' ? `${trackColor}40` : undefined }}
    >
      {/* Module Header */}
      <button
        onClick={onToggle}
        disabled={module.status === 'locked'}
        className="w-full p-4 lg:p-6 flex items-center gap-4 text-left"
      >
        <div 
          className="w-10 h-10 rounded-lg flex items-center justify-center flex-shrink-0"
          style={{ backgroundColor: `${trackColor}20` }}
        >
          {getStatusIcon()}
        </div>

        <div className="flex-1 min-w-0">
          <div className="flex items-center gap-2 mb-1">
            <h4 className="text-white font-semibold truncate">{module.title}</h4>
            {module.status === 'completed' && (
              <span className="px-2 py-0.5 rounded-full bg-green-500/20 text-green-400 text-xs">
                Done
              </span>
            )}
          </div>
          <p className="text-slate-400 text-sm truncate">{module.description}</p>
        </div>

        <div className="flex items-center gap-4">
          {module.status !== 'locked' && (
            <div className="hidden sm:block text-right">
              <div className="text-slate-400 text-xs mb-1">
                {completedVideos}/{totalVideos} videos
              </div>
              <div className="w-24 h-1.5 bg-slate-800 rounded-full overflow-hidden">
                <div 
                  className="h-full rounded-full transition-all"
                  style={{ width: `${videoProgress}%`, backgroundColor: trackColor }}
                />
              </div>
            </div>
          )}

          {module.status !== 'locked' && (
            isExpanded ? (
              <ChevronUp className="w-5 h-5 text-slate-400" />
            ) : (
              <ChevronDown className="w-5 h-5 text-slate-400" />
            )
          )}
        </div>
      </button>

      {/* Expanded Content */}
      {isExpanded && module.status !== 'locked' && (
        <div className="border-t border-white/5 p-4 lg:p-6">
          {/* Videos */}
          <div className="mb-6">
            <h5 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
              <Play className="w-4 h-4" />
              Videos ({completedVideos}/{totalVideos})
            </h5>
            <div className="space-y-2">
              {module.videos.map((video, idx) => (
                <div
                  key={video.id}
                  className={`flex items-center gap-3 p-3 rounded-lg transition-colors ${
                    video.status === 'watched'
                      ? 'bg-green-500/5'
                      : 'bg-slate-900/50 hover:bg-slate-800/50'
                  }`}
                >
                  <div className={`w-6 h-6 rounded-full flex items-center justify-center flex-shrink-0 ${
                    video.status === 'watched' ? 'bg-green-500/20' : 'bg-slate-800'
                  }`}>
                    {video.status === 'watched' ? (
                      <CheckCircle className="w-3.5 h-3.5 text-green-400" />
                    ) : (
                      <span className="text-slate-400 text-xs">{idx + 1}</span>
                    )}
                  </div>
                  <span className={`flex-1 text-sm ${
                    video.status === 'watched' ? 'text-slate-400 line-through' : 'text-white'
                  }`}>
                    {video.title}
                  </span>
                  <span className="text-slate-500 text-xs flex items-center gap-1">
                    <Clock className="w-3 h-3" />
                    {video.duration}
                  </span>
                </div>
              ))}
            </div>
          </div>

          {/* Resources */}
          {module.resources.length > 0 && (
            <div className="mb-6">
              <h5 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
                <FileText className="w-4 h-4" />
                Resources
              </h5>
              <div className="flex flex-wrap gap-2">
                {module.resources.map((resource) => (
                  <a
                    key={resource.id}
                    href={resource.url}
                    className="inline-flex items-center gap-2 px-3 py-2 rounded-lg bg-slate-900 text-slate-300 text-sm hover:bg-slate-800 transition-colors"
                  >
                    <FileText className="w-4 h-4" />
                    {resource.title}
                  </a>
                ))}
              </div>
            </div>
          )}

          {/* Exam */}
          <div>
            <h5 className="text-sm font-medium text-slate-300 mb-3 flex items-center gap-2">
              <Award className="w-4 h-4" />
              Exam
            </h5>
            <div className={`p-4 rounded-lg ${
              module.exam.status === 'completed'
                ? 'bg-green-500/5 border border-green-500/20'
                : module.exam.status === 'available'
                ? 'bg-slate-900/50 border border-slate-700/50'
                : 'bg-slate-900/30 opacity-50'
            }`}>
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-white font-medium">{module.exam.title}</p>
                  <p className="text-slate-400 text-sm">
                    {module.exam.status === 'completed'
                      ? `Score: ${module.exam.score}/${module.exam.maxScore}`
                      : module.exam.status === 'locked'
                      ? 'Complete all videos to unlock'
                      : 'Ready to take'}
                  </p>
                </div>
                {module.exam.status === 'available' && (
                  <Button size="sm" className="bg-cyan-500 hover:bg-cyan-400 text-slate-950">
                    Start Exam
                  </Button>
                )}
                {module.exam.status === 'completed' && (
                  <div className="px-3 py-1 rounded-full bg-green-500/20 text-green-400 text-sm font-medium">
                    Passed
                  </div>
                )}
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}

function TrackSection({ track }: { track: Track }) {
  const [expandedModule, setExpandedModule] = useState<string | null>(null);
  const Icon = trackIcons[track.icon as keyof typeof trackIcons] || Globe;
  const progress = track.modulesCompleted / track.totalModules;

  useEffect(() => {
    if (track.unlocked && track.modules.some(m => m.status === 'in-progress')) {
      const inProgressModule = track.modules.find(m => m.status === 'in-progress');
      if (inProgressModule) {
        setExpandedModule(inProgressModule.id);
      }
    }
  }, [track]);

  return (
    <div className="glass-card overflow-hidden" id={track.id}>
      {/* Track Header */}
      <div className="p-6 lg:p-8 border-b border-white/5">
        <div className="flex flex-col lg:flex-row lg:items-center gap-6">
          {/* Icon & Title */}
          <div className="flex items-center gap-4">
            <div
              className="w-16 h-16 rounded-2xl flex items-center justify-center"
              style={{ backgroundColor: `${track.color}20` }}
            >
              <Icon className="w-8 h-8" style={{ color: track.color }} />
            </div>
            <div>
              <h3 className="text-2xl font-bold text-white">{track.name}</h3>
              <p className="text-slate-400">{track.description}</p>
            </div>
          </div>

          {/* Progress */}
          <div className="lg:ml-auto flex-1 max-w-md">
            <div className="flex items-center justify-between mb-2">
              <span className="text-slate-400 text-sm">Track Progress</span>
              <span className="text-white font-medium">
                {track.modulesCompleted}/{track.totalModules} modules
              </span>
            </div>
            <div className="h-3 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full rounded-full transition-all duration-500"
                style={{ width: `${progress * 100}%`, backgroundColor: track.color }}
              />
            </div>
            <div className="flex items-center justify-between mt-2">
              <span 
                className="text-sm font-medium"
                style={{ color: track.color }}
              >
                Level {track.level}/{track.maxLevel}
              </span>
              <span className="text-slate-500 text-sm">
                {Math.round(progress * 100)}% complete
              </span>
            </div>
          </div>
        </div>
      </div>

      {/* Modules List */}
      <div className="p-4 lg:p-6 space-y-3">
        {track.modules.map((module) => (
          <ModuleCard
            key={module.id}
            module={module}
            trackColor={track.color}
            isExpanded={expandedModule === module.id}
            onToggle={() => setExpandedModule(
              expandedModule === module.id ? null : module.id
            )}
          />
        ))}
      </div>
    </div>
  );
}

export default function TrackingPage() {
  const { tracks, overallProgress } = useProgressStore();
  const pageRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.tracking-header', {
        y: 30,
        opacity: 0,
        duration: 0.6,
      });

      gsap.from('.track-section', {
        y: 50,
        opacity: 0,
        duration: 0.6,
        stagger: 0.2,
        scrollTrigger: {
          trigger: '.tracks-container',
          start: 'top 80%',
        },
      });
    }, pageRef);

    return () => ctx.revert();
  }, []);

  const completedModules = tracks.reduce(
    (acc, track) => acc + track.modules.filter(m => m.status === 'completed').length,
    0
  );
  const totalModules = tracks.reduce((acc, track) => acc + track.modules.length, 0);

  return (
    <div ref={pageRef} className="min-h-screen bg-slate-950">
      <Navigation />
      
      <main className="pt-24 lg:pt-32 pb-16">
        <div className="section-padding">
          {/* Header */}
          <div className="tracking-header max-w-5xl mx-auto text-center mb-12">
            <span className="text-cyan-400 text-sm font-semibold uppercase tracking-widest mb-4 block">
              Your Journey
            </span>
            <h1 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-4">
              Track Your <span className="cyber-text-gradient">Progress</span>
            </h1>
            <p className="text-slate-400 text-lg max-w-2xl mx-auto mb-8">
              Complete missions, unlock badges, and master the grid. 
              Your path to becoming a cybersecurity expert starts here.
            </p>

            {/* Overall Progress */}
            <div className="glass-card p-6 max-w-2xl mx-auto">
              <div className="flex items-center justify-between mb-3">
                <span className="text-slate-400">Overall Completion</span>
                <span className="text-white font-bold text-lg">{overallProgress}%</span>
              </div>
              <div className="h-3 bg-slate-800 rounded-full overflow-hidden mb-3">
                <div className="h-full progress-gradient rounded-full" style={{ width: `${overallProgress}%` }} />
              </div>
              <div className="flex items-center justify-between text-sm">
                <span className="text-slate-500">{completedModules} of {totalModules} modules completed</span>
                <Link 
                  to="/progress" 
                  className="text-cyan-400 hover:text-cyan-300 flex items-center gap-1"
                >
                  View Details <ArrowRight className="w-4 h-4" />
                </Link>
              </div>
            </div>
          </div>

          {/* Tracks */}
          <div className="tracks-container max-w-5xl mx-auto space-y-8">
            {tracks.map((track) => (
              <div key={track.id} className="track-section">
                <TrackSection track={track} />
              </div>
            ))}
          </div>
        </div>
      </main>

      <Footer />
    </div>
  );
}
