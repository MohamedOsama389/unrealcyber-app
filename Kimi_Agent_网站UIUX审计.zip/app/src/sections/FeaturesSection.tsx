import { useEffect, useRef } from 'react';
import { 
  GraduationCap, 
  Target, 
  Zap, 
  Trophy, 
  Users, 
  Clock 
} from 'lucide-react';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const features = [
  {
    icon: GraduationCap,
    title: 'Expert-Led Content',
    description: 'Learn from industry professionals with years of real-world cybersecurity experience.',
    color: '#00d4ff',
  },
  {
    icon: Target,
    title: 'Hands-On Labs',
    description: 'Practice in safe, isolated environments with real tools and scenarios.',
    color: '#a855f7',
  },
  {
    icon: Zap,
    title: 'Gamified Learning',
    description: 'Earn XP, unlock badges, and level up as you master new skills.',
    color: '#3b82f6',
  },
  {
    icon: Trophy,
    title: 'Industry Recognized',
    description: 'Certificates that matter. Show employers you have the skills.',
    color: '#f59e0b',
  },
  {
    icon: Users,
    title: 'Community Support',
    description: 'Join thousands of learners. Ask questions, share knowledge, grow together.',
    color: '#10b981',
  },
  {
    icon: Clock,
    title: 'Learn at Your Pace',
    description: 'Lifetime access to all content. Study when it works for you.',
    color: '#ef4444',
  },
];

export default function FeaturesSection() {
  const sectionRef = useRef<HTMLDivElement>(null);

  useEffect(() => {
    const ctx = gsap.context(() => {
      gsap.from('.features-title', {
        y: 40,
        opacity: 0,
        duration: 0.6,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });

      gsap.from('.feature-item', {
        y: 50,
        opacity: 0,
        duration: 0.5,
        stagger: 0.1,
        scrollTrigger: {
          trigger: '.features-grid',
          start: 'top 80%',
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 lg:py-32 bg-slate-950/50">
      <div className="section-padding">
        {/* Section Header */}
        <div className="features-title text-center max-w-3xl mx-auto mb-16">
          <span className="text-cyan-400 text-sm font-semibold uppercase tracking-widest mb-4 block">
            Why Choose Us
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Built for <span className="cyber-text-gradient">Serious Learners</span>
          </h2>
          <p className="text-slate-400 text-lg">
            Everything you need to go from complete beginner to job-ready cybersecurity professional.
          </p>
        </div>

        {/* Features Grid */}
        <div className="features-grid grid sm:grid-cols-2 lg:grid-cols-3 gap-6 max-w-6xl mx-auto">
          {features.map((feature, index) => {
            const Icon = feature.icon;
            return (
              <div
                key={index}
                className="feature-item glass-card-hover p-6 group"
              >
                <div
                  className="w-12 h-12 rounded-xl flex items-center justify-center mb-4 transition-transform group-hover:scale-110"
                  style={{ backgroundColor: `${feature.color}15` }}
                >
                  <Icon className="w-6 h-6" style={{ color: feature.color }} />
                </div>
                <h3 className="text-lg font-bold text-white mb-2">{feature.title}</h3>
                <p className="text-slate-400 text-sm leading-relaxed">{feature.description}</p>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
