import { useEffect, useRef } from 'react';
import { Link } from 'react-router-dom';
import { Globe, Shield, Code, ArrowRight, Lock, Play, FileText } from 'lucide-react';
import { useProgressStore } from '@/store/progressStore';
import gsap from 'gsap';
import { ScrollTrigger } from 'gsap/ScrollTrigger';

gsap.registerPlugin(ScrollTrigger);

const trackIcons = {
  Globe: Globe,
  Shield: Shield,
  Code: Code,
};

export default function TracksPreview() {
  const sectionRef = useRef<HTMLDivElement>(null);
  const cardsRef = useRef<HTMLDivElement>(null);
  const { tracks } = useProgressStore();

  useEffect(() => {
    const ctx = gsap.context(() => {
      // Section title animation
      gsap.from('.tracks-title', {
        y: 40,
        opacity: 0,
        duration: 0.6,
        scrollTrigger: {
          trigger: sectionRef.current,
          start: 'top 80%',
        },
      });

      // Cards stagger animation
      gsap.from('.track-card', {
        y: 60,
        opacity: 0,
        duration: 0.6,
        stagger: 0.15,
        scrollTrigger: {
          trigger: cardsRef.current,
          start: 'top 80%',
        },
      });
    }, sectionRef);

    return () => ctx.revert();
  }, []);

  return (
    <section ref={sectionRef} className="relative py-24 lg:py-32">
      <div className="section-padding">
        {/* Section Header */}
        <div className="tracks-title text-center max-w-3xl mx-auto mb-16">
          <span className="text-cyan-400 text-sm font-semibold uppercase tracking-widest mb-4 block">
            Learning Paths
          </span>
          <h2 className="text-3xl sm:text-4xl lg:text-5xl font-bold text-white mb-6">
            Choose Your <span className="cyber-text-gradient">Path</span>
          </h2>
          <p className="text-slate-400 text-lg">
            Three comprehensive tracks designed to take you from beginner to expert.
            Start with networking fundamentals and advance to ethical hacking mastery.
          </p>
        </div>

        {/* Track Cards */}
        <div ref={cardsRef} className="grid md:grid-cols-3 gap-6 lg:gap-8 max-w-7xl mx-auto">
          {tracks.map((track) => {
            const Icon = trackIcons[track.icon as keyof typeof trackIcons] || Globe;
            const isLocked = !track.unlocked;
            const progress = track.modulesCompleted / track.totalModules;

            return (
              <div
                key={track.id}
                className={`track-card glass-card-hover p-6 lg:p-8 relative overflow-hidden group ${
                  isLocked ? 'opacity-75' : ''
                }`}
              >
                {/* Color accent */}
                <div
                  className="absolute top-0 left-0 w-full h-1"
                  style={{ backgroundColor: track.color }}
                />

                {/* Lock overlay */}
                {isLocked && (
                  <div className="absolute inset-0 bg-slate-950/60 backdrop-blur-sm flex items-center justify-center z-10">
                    <div className="text-center">
                      <Lock className="w-12 h-12 text-slate-500 mx-auto mb-3" />
                      <p className="text-slate-400 text-sm">{track.unlockRequirement}</p>
                    </div>
                  </div>
                )}

                {/* Icon */}
                <div
                  className="w-14 h-14 rounded-xl flex items-center justify-center mb-6"
                  style={{ backgroundColor: `${track.color}20` }}
                >
                  <Icon className="w-7 h-7" style={{ color: track.color }} />
                </div>

                {/* Content */}
                <h3 className="text-xl font-bold text-white mb-2">{track.name}</h3>
                <p className="text-slate-400 text-sm mb-6">{track.description}</p>

                {/* Stats */}
                <div className="flex items-center gap-4 mb-6 text-sm">
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <Play className="w-4 h-4" />
                    <span>{track.totalModules * 3} videos</span>
                  </div>
                  <div className="flex items-center gap-1.5 text-slate-400">
                    <FileText className="w-4 h-4" />
                    <span>{track.totalModules} modules</span>
                  </div>
                </div>

                {/* Progress */}
                {!isLocked && (
                  <div className="mb-6">
                    <div className="flex justify-between text-sm mb-2">
                      <span className="text-slate-400">Progress</span>
                      <span className="text-white font-medium">
                        {Math.round(progress * 100)}%
                      </span>
                    </div>
                    <div className="h-2 bg-slate-800 rounded-full overflow-hidden">
                      <div
                        className="h-full rounded-full transition-all duration-500"
                        style={{
                          width: `${progress * 100}%`,
                          backgroundColor: track.color,
                        }}
                      />
                    </div>
                  </div>
                )}

                {/* Level badge */}
                <div className="flex items-center justify-between">
                  <div className="flex items-center gap-2">
                    <span
                      className="px-3 py-1 rounded-full text-xs font-medium"
                      style={{
                        backgroundColor: `${track.color}20`,
                        color: track.color,
                      }}
                    >
                      Level {track.level}/{track.maxLevel}
                    </span>
                  </div>

                  <Link
                    to={`/tracking#${track.id}`}
                    className="flex items-center gap-1 text-sm font-medium transition-colors group/link"
                    style={{ color: track.color }}
                  >
                    {isLocked ? 'Locked' : 'Continue'}
                    <ArrowRight className="w-4 h-4 group-hover/link:translate-x-1 transition-transform" />
                  </Link>
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </section>
  );
}
