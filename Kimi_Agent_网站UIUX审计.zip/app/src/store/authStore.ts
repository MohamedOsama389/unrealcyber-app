import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export interface User {
  id: string;
  username: string;
  email: string;
  avatar: string;
  rank: string;
  level: number;
  xp: number;
  joinedAt: string;
}

interface AuthState {
  user: User | null;
  isAuthenticated: boolean;
  login: (email: string, password: string) => Promise<boolean>;
  register: (username: string, email: string, password: string) => Promise<boolean>;
  logout: () => void;
  updateUser: (updates: Partial<User>) => void;
}

const mockUser: User = {
  id: '1',
  username: 'cyberstudent_99',
  email: 'student@unrealcyber.com',
  avatar: 'https://api.dicebear.com/7.x/avataaars/svg?seed=cyber',
  rank: 'Cyber Apprentice',
  level: 12,
  xp: 2450,
  joinedAt: '2026-01-15',
};

export const useAuthStore = create<AuthState>()(
  persist(
    (set, get) => ({
      user: null,
      isAuthenticated: false,

      login: async (email: string, password: string) => {
        // Simulate API call
        await new Promise(resolve => setTimeout(resolve, 800));
        
        if (email && password) {
          set({ user: mockUser, isAuthenticated: true });
          return true;
        }
        return false;
      },

      register: async (username: string, email: string, password: string) => {
        await new Promise(resolve => setTimeout(resolve, 800));
        
        if (username && email && password) {
          const newUser: User = {
            ...mockUser,
            username,
            email,
          };
          set({ user: newUser, isAuthenticated: true });
          return true;
        }
        return false;
      },

      logout: () => {
        set({ user: null, isAuthenticated: false });
      },

      updateUser: (updates) => {
        const { user } = get();
        if (user) {
          set({ user: { ...user, ...updates } });
        }
      },
    }),
    {
      name: 'auth-storage',
    }
  )
);
