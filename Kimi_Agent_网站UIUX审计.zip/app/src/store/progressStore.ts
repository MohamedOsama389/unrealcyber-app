import { create } from 'zustand';
import { persist } from 'zustand/middleware';

export type ModuleStatus = 'locked' | 'available' | 'in-progress' | 'completed';

export interface Video {
  id: string;
  title: string;
  duration: string;
  status: 'watched' | 'unwatched';
}

export interface Resource {
  id: string;
  title: string;
  type: 'pdf' | 'lab' | 'code';
  url: string;
}

export interface Exam {
  id: string;
  title: string;
  score: number | null;
  maxScore: number;
  status: 'locked' | 'available' | 'completed';
}

export interface Module {
  id: string;
  title: string;
  description: string;
  status: ModuleStatus;
  videos: Video[];
  resources: Resource[];
  exam: Exam;
  xpReward: number;
}

export interface Track {
  id: string;
  name: string;
  description: string;
  icon: string;
  color: string;
  level: number;
  maxLevel: number;
  modulesCompleted: number;
  totalModules: number;
  modules: Module[];
  unlocked: boolean;
  unlockRequirement: string | null;
}

export interface Achievement {
  id: string;
  title: string;
  description: string;
  icon: string;
  unlockedAt: string | null;
  rarity: 'common' | 'rare' | 'epic' | 'legendary';
}

export interface Activity {
  id: string;
  type: 'video_completed' | 'module_completed' | 'exam_passed' | 'badge_earned';
  title: string;
  timestamp: string;
}

interface ProgressState {
  tracks: Track[];
  achievements: Achievement[];
  activities: Activity[];
  overallProgress: number;
  totalXp: number;
  getCompletedModules: () => number;
  getTotalModules: () => number;
  getCompletedVideos: (trackId: string, moduleId: string) => number;
  getTotalVideos: (trackId: string, moduleId: string) => number;
  updateModuleStatus: (trackId: string, moduleId: string, status: ModuleStatus) => void;
  completeVideo: (trackId: string, moduleId: string, videoId: string) => void;
  completeExam: (trackId: string, moduleId: string, score: number) => void;
  unlockAchievement: (achievementId: string) => void;
  addActivity: (activity: Omit<Activity, 'id' | 'timestamp'>) => void;
}

const initialTracks: Track[] = [
  {
    id: 'networking',
    name: 'Networking',
    description: 'Core networking foundations and lab walkthroughs',
    icon: 'Globe',
    color: '#00d4ff',
    level: 3,
    maxLevel: 12,
    modulesCompleted: 4,
    totalModules: 24,
    unlocked: true,
    unlockRequirement: null,
    modules: [
      {
        id: 'net-1',
        title: 'OSI Model',
        description: 'Understanding the 7 layers of networking',
        status: 'completed',
        videos: [
          { id: 'v1', title: 'Introduction to OSI Model', duration: '15:00', status: 'watched' },
          { id: 'v2', title: 'Layer 1-2: Physical & Data Link', duration: '20:00', status: 'watched' },
          { id: 'v3', title: 'Layer 3-4: Network & Transport', duration: '25:00', status: 'watched' },
        ],
        resources: [
          { id: 'r1', title: 'OSI Model Cheatsheet', type: 'pdf', url: '#' },
        ],
        exam: { id: 'e1', title: 'OSI Model Exam', score: 92, maxScore: 100, status: 'completed' },
        xpReward: 100,
      },
      {
        id: 'net-2',
        title: 'IP Addressing',
        description: 'IPv4, IPv6, and addressing schemes',
        status: 'completed',
        videos: [
          { id: 'v4', title: 'IPv4 Address Structure', duration: '18:00', status: 'watched' },
          { id: 'v5', title: 'IPv6 Fundamentals', duration: '22:00', status: 'watched' },
        ],
        resources: [
          { id: 'r2', title: 'IP Addressing Guide', type: 'pdf', url: '#' },
        ],
        exam: { id: 'e2', title: 'IP Addressing Exam', score: 88, maxScore: 100, status: 'completed' },
        xpReward: 100,
      },
      {
        id: 'net-3',
        title: 'Subnetting',
        description: 'Master subnet calculations and CIDR',
        status: 'completed',
        videos: [
          { id: 'v6', title: 'Subnet Mask Basics', duration: '20:00', status: 'watched' },
          { id: 'v7', title: 'CIDR Notation', duration: '15:00', status: 'watched' },
        ],
        resources: [
          { id: 'r3', title: 'Subnet Calculator Tool', type: 'code', url: '#' },
        ],
        exam: { id: 'e3', title: 'Subnetting Exam', score: 95, maxScore: 100, status: 'completed' },
        xpReward: 150,
      },
      {
        id: 'net-4',
        title: 'Routing Basics',
        description: 'Static and dynamic routing fundamentals',
        status: 'completed',
        videos: [
          { id: 'v8', title: 'Routing Concepts', duration: '25:00', status: 'watched' },
          { id: 'v9', title: 'Static Routes', duration: '18:00', status: 'watched' },
        ],
        resources: [
          { id: 'r4', title: 'Routing Lab', type: 'lab', url: '#' },
        ],
        exam: { id: 'e4', title: 'Routing Exam', score: 85, maxScore: 100, status: 'completed' },
        xpReward: 150,
      },
      {
        id: 'net-5',
        title: 'Switching',
        description: 'Layer 2 switching and VLANs',
        status: 'in-progress',
        videos: [
          { id: 'v10', title: 'Switch Fundamentals', duration: '15:00', status: 'watched' },
          { id: 'v11', title: 'MAC Address Table', duration: '12:00', status: 'watched' },
          { id: 'v12', title: 'Frame Forwarding', duration: '18:00', status: 'unwatched' },
          { id: 'v13', title: 'Switch Configuration', duration: '25:00', status: 'unwatched' },
        ],
        resources: [
          { id: 'r5', title: 'Switch Commands Cheatsheet', type: 'pdf', url: '#' },
          { id: 'r6', title: 'Packet Tracer Lab', type: 'lab', url: '#' },
        ],
        exam: { id: 'e5', title: 'Switching Exam', score: null, maxScore: 100, status: 'locked' },
        xpReward: 200,
      },
      {
        id: 'net-6',
        title: 'VLANs',
        description: 'Virtual LAN configuration and trunking',
        status: 'locked',
        videos: [
          { id: 'v14', title: 'VLAN Concepts', duration: '20:00', status: 'unwatched' },
          { id: 'v15', title: 'VLAN Configuration', duration: '30:00', status: 'unwatched' },
        ],
        resources: [
          { id: 'r7', title: 'VLAN Lab Guide', type: 'lab', url: '#' },
        ],
        exam: { id: 'e6', title: 'VLAN Exam', score: null, maxScore: 100, status: 'locked' },
        xpReward: 200,
      },
    ],
  },
  {
    id: 'ethical-hacking',
    name: 'Ethical Hacking',
    description: 'Red-team mindset, tooling, and practical exploits',
    icon: 'Shield',
    color: '#a855f7',
    level: 0,
    maxLevel: 15,
    modulesCompleted: 0,
    totalModules: 30,
    unlocked: false,
    unlockRequirement: 'Complete Networking Level 5',
    modules: [
      {
        id: 'eh-1',
        title: 'Introduction to Ethical Hacking',
        description: 'Ethics, legality, and methodology',
        status: 'locked',
        videos: [
          { id: 'v16', title: 'What is Ethical Hacking?', duration: '20:00', status: 'unwatched' },
        ],
        resources: [
          { id: 'r8', title: 'Ethics Guidelines', type: 'pdf', url: '#' },
        ],
        exam: { id: 'e7', title: 'Ethics Exam', score: null, maxScore: 100, status: 'locked' },
        xpReward: 100,
      },
    ],
  },
  {
    id: 'programming',
    name: 'Programming',
    description: 'Build scripts, automation, and security tooling',
    icon: 'Code',
    color: '#3b82f6',
    level: 0,
    maxLevel: 10,
    modulesCompleted: 0,
    totalModules: 20,
    unlocked: false,
    unlockRequirement: 'Complete Networking Level 3',
    modules: [
      {
        id: 'prog-1',
        title: 'Python Basics',
        description: 'Python fundamentals for security',
        status: 'locked',
        videos: [
          { id: 'v17', title: 'Python Setup', duration: '15:00', status: 'unwatched' },
        ],
        resources: [
          { id: 'r9', title: 'Python Cheatsheet', type: 'pdf', url: '#' },
        ],
        exam: { id: 'e8', title: 'Python Basics Exam', score: null, maxScore: 100, status: 'locked' },
        xpReward: 100,
      },
    ],
  },
];

const initialAchievements: Achievement[] = [
  {
    id: 'first-steps',
    title: 'First Steps',
    description: 'Complete your first module',
    icon: 'Footprints',
    unlockedAt: '2026-01-20',
    rarity: 'common',
  },
  {
    id: 'week-warrior',
    title: 'Week Warrior',
    description: 'Study for 7 consecutive days',
    icon: 'Flame',
    unlockedAt: '2026-01-25',
    rarity: 'common',
  },
  {
    id: 'osi-master',
    title: 'OSI Master',
    description: 'Score 90%+ on OSI Model exam',
    icon: 'Layers',
    unlockedAt: '2026-01-22',
    rarity: 'rare',
  },
  {
    id: 'subnet-guru',
    title: 'Subnet Guru',
    description: 'Score 95%+ on Subnetting exam',
    icon: 'Network',
    unlockedAt: '2026-02-01',
    rarity: 'epic',
  },
  {
    id: 'perfect-score',
    title: 'Perfect Score',
    description: 'Get 100% on any exam',
    icon: 'Trophy',
    unlockedAt: null,
    rarity: 'legendary',
  },
];

const initialActivities: Activity[] = [
  {
    id: '1',
    type: 'video_completed',
    title: 'Completed "Frame Forwarding" video',
    timestamp: '2026-02-19T14:30:00Z',
  },
  {
    id: '2',
    type: 'badge_earned',
    title: 'Earned "Switch Starter" badge',
    timestamp: '2026-02-19T11:15:00Z',
  },
  {
    id: '3',
    type: 'module_completed',
    title: 'Started Module 5: Switching',
    timestamp: '2026-02-18T09:00:00Z',
  },
  {
    id: '4',
    type: 'exam_passed',
    title: 'Passed Subnetting Exam (95%)',
    timestamp: '2026-02-16T16:45:00Z',
  },
];

export const useProgressStore = create<ProgressState>()(
  persist(
    (set, get) => ({
      tracks: initialTracks,
      achievements: initialAchievements,
      activities: initialActivities,
      overallProgress: 34,
      totalXp: 2450,

      getCompletedModules: () => {
        const { tracks } = get();
        return tracks.reduce((acc, track) => 
          acc + track.modules.filter(m => m.status === 'completed').length, 0
        );
      },

      getTotalModules: () => {
        const { tracks } = get();
        return tracks.reduce((acc, track) => acc + track.modules.length, 0);
      },

      getCompletedVideos: (trackId: string, moduleId: string) => {
        const { tracks } = get();
        const track = tracks.find(t => t.id === trackId);
        const module = track?.modules.find(m => m.id === moduleId);
        return module?.videos.filter(v => v.status === 'watched').length || 0;
      },

      getTotalVideos: (trackId: string, moduleId: string) => {
        const { tracks } = get();
        const track = tracks.find(t => t.id === trackId);
        const module = track?.modules.find(m => m.id === moduleId);
        return module?.videos.length || 0;
      },

      updateModuleStatus: (trackId: string, moduleId: string, status: ModuleStatus) => {
        set(state => ({
          tracks: state.tracks.map(track =>
            track.id === trackId
              ? {
                  ...track,
                  modules: track.modules.map(module =>
                    module.id === moduleId ? { ...module, status } : module
                  ),
                }
              : track
          ),
        }));
      },

      completeVideo: (trackId: string, moduleId: string, videoId: string) => {
        set(state => ({
          tracks: state.tracks.map(track =>
            track.id === trackId
              ? {
                  ...track,
                  modules: track.modules.map(module =>
                    module.id === moduleId
                      ? {
                          ...module,
                          videos: module.videos.map(video =>
                            video.id === videoId ? { ...video, status: 'watched' as const } : video
                          ),
                        }
                      : module
                  ),
                }
              : track
          ),
        }));
      },

      completeExam: (trackId: string, moduleId: string, score: number) => {
        set(state => ({
          tracks: state.tracks.map(track =>
            track.id === trackId
              ? {
                  ...track,
                  modules: track.modules.map(module =>
                    module.id === moduleId
                      ? {
                          ...module,
                          exam: { ...module.exam, score, status: 'completed' as const },
                          status: 'completed' as const,
                        }
                      : module
                  ),
                }
              : track
          ),
        }));
      },

      unlockAchievement: (achievementId: string) => {
        set(state => ({
          achievements: state.achievements.map(achievement =>
            achievement.id === achievementId && !achievement.unlockedAt
              ? { ...achievement, unlockedAt: new Date().toISOString() }
              : achievement
          ),
        }));
      },

      addActivity: (activity) => {
        set(state => ({
          activities: [
            {
              ...activity,
              id: Date.now().toString(),
              timestamp: new Date().toISOString(),
            },
            ...state.activities,
          ].slice(0, 50),
        }));
      },
    }),
    {
      name: 'progress-storage',
    }
  )
);
